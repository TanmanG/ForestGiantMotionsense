# **Forest Giant Motionsense**

## **Add a little counterplay to Forest Giants!**

**This mod makes Forest Giants only act (look at and start chasing) moving players.**

It's frustrating to have to hike a mile back with 80lbs of scrap, only to get stuck between a rock and a Forest Giant. You're left either having to strip down to an empty inventory and flee, or accept your fate and be taken.

This mod aims to fix that by tweaking the Forest Giant AI to only stare and consequently chase players who have moved within the last second.


## **Encounter an issue?**

Send me a message on Discord @tanmang, or an email at mangomango.dev@gmail.com



Tested working for V61. Incompatible with anything that considerably modifies/replaces/skips ForestGiantAI.SearchForPlayers() and PlayerControllerB.UpdatePlayerPositionClientRpc().



~ Requested by rainycake ~
